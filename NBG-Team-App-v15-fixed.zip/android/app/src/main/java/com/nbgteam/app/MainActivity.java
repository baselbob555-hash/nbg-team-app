package com.nbgteam.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    // رابط الواجهة المستضافة على GitHub Pages — أي تعديل هناك يظهر تلقائياً بدون تحديث APK
    static final String REMOTE_URL = "https://baselbob555-hash.github.io/nbg-team-app/";
    private static final int NOTIF_PERMISSION_CODE = 1001;

    WebView webView;
    volatile String cachedFcmToken = "";

    // جسر آمن يستدعيه الجافاسكريبت داخل الصفحة لمعرفة توكن الإشعارات الخاص بهذا الجهاز
    class AndroidBridge {
        @JavascriptInterface
        public String getFcmToken() {
            return cachedFcmToken == null ? "" : cachedFcmToken;
        }
    }

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestNotificationPermissionIfNeeded();
        fetchFcmToken();

        webView = new WebView(this);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            boolean fallbackUsed = false;
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame() && !fallbackUsed) {
                    fallbackUsed = true;
                    Log.d("NBGTeam", "تعذر تحميل النسخة عبر الإنترنت، جارِ استخدام النسخة المحلية المخزنة داخل التطبيق.");
                    view.loadUrl("file:///android_asset/index.html");
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d("NBGTeam", cm.message() + " -- line " + cm.lineNumber() + " of " + cm.sourceId());
                return true;
            }
        });
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        // لا تخزين مؤقت لملف الواجهة أبداً — اجلب دائماً أحدث نسخة من الإنترنت
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.clearCache(true);
        webView.loadUrl(REMOTE_URL + "?v=" + System.currentTimeMillis());
        setContentView(webView);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION_CODE);
            }
        }
    }

    private void fetchFcmToken() {
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                cachedFcmToken = task.getResult();
                Log.d("NBGTeam", "FCM token ready: " + cachedFcmToken);
            } else {
                Log.d("NBGTeam", "Failed to fetch FCM token", task.getException());
            }
        });
    }
}
