package com.nbgteam.app;
import android.app.Activity;import android.os.Bundle;import android.util.Log;import android.webkit.ConsoleMessage;import android.webkit.WebChromeClient;import android.webkit.WebResourceError;import android.webkit.WebResourceRequest;import android.webkit.WebSettings;import android.webkit.WebView;import android.webkit.WebViewClient;

public class MainActivity extends Activity{
 // رابط الواجهة المستضافة على GitHub Pages — أي تعديل هناك يظهر تلقائياً بدون تحديث APK
 static final String REMOTE_URL="https://baselbob555-hash.github.io/nbg-team-app/";

 protected void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  w.setWebViewClient(new WebViewClient(){
   boolean fallbackUsed=false;
   public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err){
    if(req.isForMainFrame() && !fallbackUsed){
     fallbackUsed=true;
     Log.d("NBGTeam","تعذر تحميل النسخة عبر الإنترنت، جارِ استخدام النسخة المحلية المخزنة داخل التطبيق.");
     view.loadUrl("file:///android_asset/index.html");
    }
   }
  });
  w.setWebChromeClient(new WebChromeClient(){
   public boolean onConsoleMessage(ConsoleMessage cm){
    Log.d("NBGTeam", cm.message()+" -- line "+cm.lineNumber()+" of "+cm.sourceId());
    return true;
   }
  });
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  w.loadUrl(REMOTE_URL);
  setContentView(w);
 }
}
