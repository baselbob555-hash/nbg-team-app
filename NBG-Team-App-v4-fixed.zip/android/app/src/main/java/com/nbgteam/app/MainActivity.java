package com.nbgteam.app;
import android.app.Activity;import android.os.Bundle;import android.util.Log;import android.webkit.ConsoleMessage;import android.webkit.WebChromeClient;import android.webkit.WebSettings;import android.webkit.WebView;import android.webkit.WebViewClient;
public class MainActivity extends Activity{
 protected void onCreate(Bundle b){
  super.onCreate(b);
  WebView w=new WebView(this);
  w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient(){
   public boolean onConsoleMessage(ConsoleMessage cm){
    Log.d("NBGTeam", cm.message()+" -- line "+cm.lineNumber()+" of "+cm.sourceId());
    return true;
   }
  });
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  w.loadUrl("file:///android_asset/index.html");
  setContentView(w);
 }
}
