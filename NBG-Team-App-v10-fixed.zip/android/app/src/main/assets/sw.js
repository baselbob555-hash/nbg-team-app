const CACHE='nbg-team-v5';
const ASSETS=['./','./index.html','./manifest.webmanifest','./logo.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{
 if(e.request.method!=='GET')return;
 // شبكة أولاً حتى تظهر آخر التعديلات فوراً، ونسخة محفوظة فقط عند انعدام الإنترنت
 e.respondWith(
  fetch(e.request).then(r=>{let copy=r.clone();caches.open(CACHE).then(x=>x.put(e.request,copy));return r})
  .catch(()=>caches.match(e.request).then(c=>c||caches.match('./index.html')))
 );
});
